package com.pocket.app.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.pocket.app.PocketApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val app = context.applicationContext as? PocketApplication ?: return
            CoroutineScope(Dispatchers.IO).launch {
                val activeReminders = app.repository.getActiveReminders().first()
                for (reminder in activeReminders) {
                    ReminderScheduler.scheduleReminder(context, reminder)
                }
            }
        }
    }
}
